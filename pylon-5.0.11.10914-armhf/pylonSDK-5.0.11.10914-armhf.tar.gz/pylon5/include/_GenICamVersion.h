//  This file is generated automatically. Do not modify! 
#define GENICAM_VERSION_MAJOR 3 
#define GENICAM_VERSION_MINOR 0 
#define GENICAM_VERSION_SUBMINOR 1

#define GENICAM_MAIN_COMPILER 

#define GENICAM_COMPANY_SUFFIX Basler_pylon_v5_0
#define GENICAM_SVN_REVISION 4512
